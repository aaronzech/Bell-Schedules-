package com.example.zechaaron.schoolschedules;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class Analyzer {



    public Date analizeTime(String time) {

        Date x=null;

        try {
            // Hour 1
            Date time1 = new SimpleDateFormat("HH:mm:ss").parse(time);
            Calendar calendar1 = Calendar.getInstance();
            calendar1.setTime(time1);
            x = calendar1.getTime();
            return x;

        } catch (ParseException e) {
            e.printStackTrace();

        }
        return x;

    }
}
