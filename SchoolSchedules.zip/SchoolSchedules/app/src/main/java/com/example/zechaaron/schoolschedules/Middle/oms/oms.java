package com.example.zechaaron.schoolschedules.Middle.oms;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.example.zechaaron.schoolschedules.MainActivity;
import com.example.zechaaron.schoolschedules.R;

public class oms extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_oms);

        // Spinner Logic
        Spinner mySpinner = (Spinner) findViewById(R.id.spinnerTeam);

        ArrayAdapter<String> myAdapter = new ArrayAdapter<>(oms.this,
                android.R.layout.simple_list_item_1,getResources().getStringArray(R.array.omsTeams));

        myAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        mySpinner.setAdapter(myAdapter);

        mySpinner.setOnItemSelectedListener(this);

    }
    // Go back button - Takes user to main app screen
    public void goHome(View view)
    {
        startActivity(new Intent(oms.this,MainActivity.class));
    }

    public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
    {
        String s = parent.getItemAtPosition(position).toString();
        //Toast.makeText(this,s,Toast.LENGTH_LONG).show();
        if(s.equals("Maple Grove Senior"))
        {

        }
        if(s.equals("Brooklyn Middle"))
        {

        }
        if(s.equals("Osseo Middle"))
        {

        }

        if(s.equals("Park Center Senior"))
        {

        }

    }
    public void onNothingSelected(AdapterView<?> parent)
    {

    }

}
