package com.example.zechaaron.schoolschedules.Middle;

        import android.content.Intent;
        import android.support.v7.app.AppCompatActivity;
        import android.os.Bundle;
        import android.util.Log;
        import android.view.View;
        import android.widget.TextView;
        import android.widget.Toast;
// Time
        import com.example.zechaaron.schoolschedules.Analyzer;
        import com.example.zechaaron.schoolschedules.MainActivity;
        import com.example.zechaaron.schoolschedules.R;

        import java.text.ParseException;
        import java.text.SimpleDateFormat;
        import java.util.Calendar;
        import java.util.*;

public class bms extends AppCompatActivity{


    //Monday-Friday Scheudle
    String hour1Start="08:10:00";
    String hour1End="09:14:00";

    String hour2Start="09:18:00";
    String hour2End="10:03:00";

    String hour3Start="10:07:00";
    String hour3End="10:52:00";

    String hour4Start="10:56:00";
    String hour4End="11:41:00";

    String hour5Start="11:41:00";
    String hour5End="13:02:00"; // 24 hour time here?

    String hour6Start="13:06:00";
    String hour6End="13:51:00";

    String hour7Start="13:55:00";
    String hour7End="14:40:00";

    String fullSchedule = null;

    // Fetch analyzer class
    Analyzer analyzer = new Analyzer();

    // Time Start and End times
    public static final String ENDOFDAY = "14:40:00";
    public static final String STARTOFDAY = "08:10:00";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bms);
        getCurrentTime();

        getDayOfWeek();
        // notification();

        TextView dailySchedule = (TextView) findViewById(R.id.currentDaySchedule);
        dailySchedule.setText(getDayOfWeek()+" Schedule");

        TextView dailyScheduleFull = (TextView) findViewById(R.id.currentDayScheduleFull);
        dailyScheduleFull.setText(fullSchedule);

        // New thread // Auto update Time
        Thread t = new Thread()
        {
            public void run()
            {
                while(!isInterrupted())
                {
                    try{
                        Thread.sleep(500);
                        runOnUiThread(new Runnable()
                        {
                            public void run()
                            {
                                getCurrentTime();
                            }
                        });
                    }catch (InterruptedException e)
                    {
                        e.printStackTrace();
                    }
                }
            }

        };

        t.start();

    }

    // Calulates the current day of the week, and returns it as a string
    private String getDayOfWeek()
    {
        // Get day of the week
        SimpleDateFormat dayFormat = new SimpleDateFormat("EEEE");
        Calendar calendar = Calendar.getInstance();
        String dayOfWeek = dayFormat.format(calendar.getTime());
        TextView dayTextview = (TextView) findViewById(R.id.day);
        dayTextview.setText(dayOfWeek);
        Log.d("mytag",dayOfWeek);

        fullSchedule = "Period 1 - 8:10-9:14 \nPeriod 2 9:18-10:03\nPeriod 3 10:07-10:52\nPeriod 4 10:56-11:41\nPeriod 5 11:45-1:02 \nPeriod 6 1:06-1:51 \nPeriod 7 1:55-2:40";

        return  dayOfWeek;

    }

    String currentTime = null;
    String hour = null;
    public void getCurrentTime()  {
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat mdformat = new SimpleDateFormat("hh:mm:ss a"); //a for am

        String strDate =  mdformat.format(calendar.getTime());
        display(strDate);
        currentTime =  mdformat.format(calendar.getTime());
        whatHourIsIt(currentTime);

    }
    // Go back button - Takes user to main app screen
    public void goHome(View view)
    {
        startActivity(new Intent(bms.this,MainActivity.class));
    }

    private void display(String num) {
        TextView textView = (TextView) findViewById(R.id.current_hour);
        textView.setText(num);

        TextView textViewNew = (TextView) findViewById(R.id.display_text_view);
        textViewNew.setText(hour);
    }

    // MGSH Schedule
    // HOUR 1 7:30-8:25
    private void whatHourIsIt(String currentTime)
    {

        try {
            // Current TIME
            Date d = new SimpleDateFormat("HH:mm:ss").parse(currentTime);
            Calendar calendarZ = Calendar.getInstance();
            calendarZ.setTime(d);
            //calendarZ.add(Calendar.DATE, 1);

            Date x = calendarZ.getTime();


                //Hour 1 check
                if(x.after(analyzer.analizeTime(hour1Start)) && x.before(analyzer.analizeTime(hour1End)))
                {
                    hour = "Period 1";
                }
                else if (x.after(analyzer.analizeTime(hour2Start)) && x.before(analyzer.analizeTime(hour2End)))
                {
                    hour = "Period 2";
                }
                else if (x.after(analyzer.analizeTime(hour3Start)) && x.before(analyzer.analizeTime(hour3End)))
                {
                    hour = "Period 3";
                }
                else if (x.after(analyzer.analizeTime(hour4Start)) && x.before(analyzer.analizeTime(hour4End)))
                {
                    hour = "Period 4";
                }
                else if (x.after(analyzer.analizeTime(hour5Start)) && x.before(analyzer.analizeTime(hour5End)))
                {
                    hour = "Period 5";
                }
                else if (x.after(analyzer.analizeTime(hour6Start)) && x.before(analyzer.analizeTime(hour6End)))
                {
                    hour = "Period 6";
                }
                else if (x.after(analyzer.analizeTime(hour7Start)) && x.before(analyzer.analizeTime(hour7End)))
                {
                    hour = "Period 7";
                }
                else if(x.after(analyzer.analizeTime(STARTOFDAY)) && x.before(analyzer.analizeTime(ENDOFDAY)))
                {
                    hour = "Passing Time";
                }
                else
                {
                    hour = "No Active Classes";
                }

            // Adjusted Schedule
        } catch (ParseException e) {
            e.printStackTrace();
            Toast.makeText(this,"ERROR",Toast.LENGTH_LONG).show();
        }

    }

}
