package com.example.zechaaron.schoolschedules.High;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
// Time
import com.example.zechaaron.schoolschedules.Analyzer;
import com.example.zechaaron.schoolschedules.MainActivity;
import com.example.zechaaron.schoolschedules.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.*;

public class MGSH extends AppCompatActivity{

    // School Schedule
    //--------------------------------
    String hour1Start;
    String hour1End;
    String hour2Start;
    String hour2End;
    String hour3Start;
    String hour3End;
    String hour4Start;
    String hour4End;
    String hour5Start;
    String hour5End;
    String hour6Start;
    String hour6End;
    String crimsonHourStart=null;
    String crimsonHourEnd=null;
    String foundationStart=null;
    String foundationsEnd=null;
    String fullSchedule = null;
    String currentTime = null;
    String hour = null;
    Date x = null;

    // Fetch analyzer class
    Analyzer analyzer = new Analyzer();

    // School name preference hour/block/period
    public static final String PREF = "Hour ";

    // Time Start and End times
    public static final String ENDOFDAY = "14:00:00";
    public static final String STARTOFDAY = "07:30:00";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mgsh);

        // Compute Current Time
        getCurrentTime();
        // Compute Day of the week.
        getDayOfWeek();

        //TextView dailySchedule = (TextView) findViewById(R.id.currentDaySchedule);
        //dailySchedule.setText(getDayOfWeek()+" Schedule");

        TextView dailyScheduleFull = (TextView) findViewById(R.id.currentDayScheduleFull);
        dailyScheduleFull.setText(fullSchedule);

        // New thread // Auto update Time
        Thread t = new Thread()
        {
            public void run()
            {
                while(!isInterrupted())
                {
                    try{
                        Thread.sleep(500); // was 1000
                        runOnUiThread(new Runnable()
                        {
                            public void run()
                            {
                                getCurrentTime();
                            }
                        });
                    }catch (InterruptedException e)
                    {
                        e.printStackTrace();
                    }
                }
            }

        };
        t.start();
    }

    // Calulates the current day of the week, and returns it as a string
    private String getDayOfWeek()
    {
        // Get day of the week in "MONDAY" format
        SimpleDateFormat dayFormat = new SimpleDateFormat("EEEE");
        Calendar calendar = Calendar.getInstance();
        String dayOfWeek = dayFormat.format(calendar.getTime());

        TextView dayTextview = (TextView) findViewById(R.id.day);
       dayTextview.setText(dayOfWeek);


        // Select the schedule based on the day of the week
        if(dayOfWeek.equals("Tuesday"))
        {
            //Tuesday Scheudle
            crimsonHourStart="07:30:00";
            crimsonHourEnd="07:55:00";
            hour1Start="08:00:00";
            hour1End="09:20:00";
            hour2Start="09:25:00";
            hour2End="10:45:00";
            hour4Start="10:50:00";
            hour4End="12:35:00";
            hour5Start="12:40:00";
            hour5End="14:00:00";

            fullSchedule = "Crimson Hour - 7:30-7:55 \nHour 1 8:00-9:20\nHour 2 9:25-10:45\nHour 4 10:50-12:35 \n Hour 5 12:40-2:00";

        }
        else if(dayOfWeek.equals("Monday") || dayOfWeek.equals("Friday"))
        {
            //Monday-Friday Scheudle
            hour1Start="07:30:00";
            hour1End="08:25:00";
            hour2Start="08:30:00";
            hour2End="09:25:00";
            hour3Start="9:30:00";
            hour3End="10:25:00";
            hour4Start="10:30:00";
            hour4End="12:00:00";
            hour5Start="12:05:00";
            hour5End="01:00:00"; // 24 hour time here?
            hour6Start="01:05:00";
            hour6End="14:00:00";

            fullSchedule = "Hour 1 - 7:30-8:25 \nHour 2 8:25-9:25\nHour 3 9:30-10:25\nHour 4 10:30-12:00 \n Hour 5 12:05-1:00 \n Hour 6 1:05-2:00";
        }
        else if(dayOfWeek.equals("Wednesday"))
        {
            hour1Start="07:30:00";
            hour1End="08:50:00";
            foundationStart="8:55:00";
            foundationsEnd="9:20:00";
            hour3Start="9:25:00";
            hour3End="10:45:00";
            hour4Start="10:50:00";
            hour4End="12:35:00";
            hour6Start="12:40:00";
            hour6End="14:00:00";

            fullSchedule = "Hour 1 - 7:30-8:50 \nFoundations 8:55-9:20\nHour 3 9:25-10:45\nHour 4 10:50-12:35 \n Hour 6 12:40-2:00";
        }
        else
        {
            //Thrusday
            crimsonHourStart="07:30:00";
            crimsonHourEnd="07:55:00";
            hour2Start="08:00:00";
            hour2End="09:20:00";
            hour3Start="09:25:00";
            hour3End="10:45:00";
            hour5Start="10:50:00";
            hour5End="12:35:00";
            hour6Start="12:40:00";
            hour6End="14:00:00"; // 24 hour time here?

            fullSchedule = "Crimson Hour - 7:30-7:55 \nHour 2 8:00-9:20\nHour 3 9:25-10:45\nHour 5 10:50-12:35 \nHour 6 12:40-2:00";
        }
        return  dayOfWeek;
    }

    public void getCurrentTime()  {
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat mdformat = new SimpleDateFormat("HH:mm:ss"); // Math clock


        // Display Current time
        SimpleDateFormat dislaymdformat = new SimpleDateFormat("hh:mm:ss a"); // Display clock
        String strDate =  dislaymdformat.format(calendar.getTime());
        display(strDate);


        // Figure out what class is active
        currentTime =  mdformat.format(calendar.getTime());
        whatHourIsIt(currentTime);
    }

    // Go back button - Takes user to main app screen
    public void goHome(View view)
    {
        startActivity(new Intent(MGSH.this,MainActivity.class));
    }

    // Display info to the screen
    private void display(String num) {
        TextView textView = (TextView) findViewById(R.id.current_hour);
        textView.setText(num);

        TextView textViewNew = (TextView) findViewById(R.id.display_text_view);
        textViewNew.setText(hour);
    }

    private void whatHourIsIt(String currentTime)
    {
        try {
            // Current TIME
            Date d = new SimpleDateFormat("HH:mm:ss").parse(currentTime);
            Calendar calendarZ = Calendar.getInstance();
            calendarZ.setTime(d);
            //calendarZ.add(Calendar.DATE, 1);

            Date x = calendarZ.getTime();

            if (getDayOfWeek().equals("Monday") || getDayOfWeek().equals("Friday"))
            {
                //Hour 1 check
                if(x.after(analyzer.analizeTime(hour1Start)) && x.before(analyzer.analizeTime(hour1End)))
                {
                    hour = PREF +"1";
                }
                else if (x.after(analyzer.analizeTime(hour2Start)) && x.before(analyzer.analizeTime(hour2End)))
                {
                    hour = PREF +"2";
                }
                else if (x.after(analyzer.analizeTime(hour3Start)) && x.before(analyzer.analizeTime(hour3End)))
                {
                    hour = PREF +"3";
                }
                else if (x.after(analyzer.analizeTime(hour4Start)) && x.before(analyzer.analizeTime(hour4End)))
                {
                    hour = PREF +"4";
                }
                else if (x.after(analyzer.analizeTime(hour5Start)) && x.before(analyzer.analizeTime(hour5End)))
                {
                    hour = PREF +"5";
                }
                else if (x.after(analyzer.analizeTime(hour6Start)) && x.before(analyzer.analizeTime(hour6End)))
                {
                    hour = PREF +"6";
                }
                else if(x.after(analyzer.analizeTime(STARTOFDAY)) && x.before(analyzer.analizeTime(ENDOFDAY)))
                {
                    hour = "Passing Time";
                }
                else
                {
                    hour = "No Active Classes";
                }
            }

            // Tuesday, Wednesday, Thrusday Scheudle
            if((getDayOfWeek().equals("Tuesday")))
            {
                //Crimson Hour
                if(x.after(analyzer.analizeTime(crimsonHourStart)) && x.before(analyzer.analizeTime(crimsonHourEnd)))
                {
                    hour = "Crimson Hour";
                }
                // 1 Hour
                else if(x.after(analyzer.analizeTime(hour1Start)) && x.before(analyzer.analizeTime(hour1End)))
                {
                    hour = PREF +"1";
                }
                //2nd Hour
                else if(x.after(analyzer.analizeTime(hour2Start)) && x.before(analyzer.analizeTime(hour2End)))
                {
                    hour = PREF +"2";
                }
                // 4th hour
                else if(x.after(analyzer.analizeTime(hour4Start)) && x.before(analyzer.analizeTime(hour4End)))
                {
                    hour = PREF +"4";
                }
                // 5th hour
                else if(x.after(analyzer.analizeTime(hour5Start)) && x.before(analyzer.analizeTime(hour5End)))
                {
                    hour = PREF +"5";
                }
                else if(x.after(analyzer.analizeTime(STARTOFDAY)) && x.before(analyzer.analizeTime(ENDOFDAY)))
                {
                    hour = "Passing Time";
                }
                else
                {
                    hour = "No Active Classes";
                }
            }

            if((getDayOfWeek().equals("Wednesday")))
            {
                //1st Hour
                if(x.after(analyzer.analizeTime(hour1Start)) && x.before(analyzer.analizeTime(hour1End)))
                {
                    hour = PREF +"1";
                }
                // Foundaitons
                else if(x.after(analyzer.analizeTime(foundationStart)) && x.before(analyzer.analizeTime(foundationsEnd)))
                {
                    hour = "Foundations";
                }
                //3nd Hour
                else if(x.after(analyzer.analizeTime(hour3Start)) && x.before(analyzer.analizeTime(hour3End)))
                {
                    hour = PREF +"3";
                }

                // 4th hour
                else if(x.after(analyzer.analizeTime(hour4Start)) && x.before(analyzer.analizeTime(hour4End)))
                {
                    hour = PREF +"4";
                }

                // 6th hour
                else if(x.after(analyzer.analizeTime(hour6Start)) && x.before(analyzer.analizeTime(hour6End)))
                {
                    hour = PREF +"6";
                }
                else if(x.after(analyzer.analizeTime(STARTOFDAY)) && x.before(analyzer.analizeTime(ENDOFDAY)))
                {
                    hour = "Passing Time";
                }
                else
                {
                    hour = "No Active Classes";
                }
            }

            if((getDayOfWeek().equals("Thursday")))
            {
                // Crimson Hour
                if(x.after(analyzer.analizeTime(crimsonHourStart)) && x.before(analyzer.analizeTime(crimsonHourEnd)))
                {
                    hour = "Crimson Hour";
                }
                // 2nd hour
               else if(x.after(analyzer.analizeTime(hour2Start)) && x.before(analyzer.analizeTime(hour2End)))
                {
                    hour = PREF +"2";
                }
                //3nd Hour
                else if(x.after(analyzer.analizeTime(hour3Start)) && x.before(analyzer.analizeTime(hour3End)))
                {
                    hour = PREF +"3";
                }
                // 5th hour
               else if(x.after(analyzer.analizeTime(hour5Start)) && x.before(analyzer.analizeTime(hour5End)) )
                {
                    hour = PREF +"5";
                }
                // 6th hour
                else if(x.after(analyzer.analizeTime(hour6Start)) && x.before(analyzer.analizeTime(hour6End)))
                {
                    hour = "6th Hour";
                }
                else if(x.after(analyzer.analizeTime(STARTOFDAY)) && x.before(analyzer.analizeTime(ENDOFDAY)))
                {
                    hour = "Passing Time";
                }
                else
                {
                    hour = "No Active Classes";
                }

            }

        } catch (ParseException e) {
            e.printStackTrace();
            Toast.makeText(this,"ERROR",Toast.LENGTH_LONG).show();
        }

    }
}
