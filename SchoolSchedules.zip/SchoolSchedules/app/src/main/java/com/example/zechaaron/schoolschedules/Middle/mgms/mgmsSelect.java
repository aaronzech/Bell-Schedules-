package com.example.zechaaron.schoolschedules.Middle.mgms;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.example.zechaaron.schoolschedules.MainActivity;
import com.example.zechaaron.schoolschedules.Middle.oms.omsSelect;
import com.example.zechaaron.schoolschedules.Middle.oms.omsTeam1;
import com.example.zechaaron.schoolschedules.Middle.oms.omsTeam2;
import com.example.zechaaron.schoolschedules.Middle.oms.omsTeam3;
import com.example.zechaaron.schoolschedules.Middle.oms.omsTeam4;
import com.example.zechaaron.schoolschedules.Middle.oms.omsTeam5;
import com.example.zechaaron.schoolschedules.Middle.oms.omsTeam6;
import com.example.zechaaron.schoolschedules.R;

public class mgmsSelect extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mgms_select);

        // Spinner Logic
        Spinner mySpinner = (Spinner) findViewById(R.id.spinnerTeam);

        ArrayAdapter<String> myAdapter = new ArrayAdapter<>(mgmsSelect.this,
                android.R.layout.simple_list_item_1,getResources().getStringArray(R.array.mgmsTeams));

        myAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        mySpinner.setAdapter(myAdapter);

        mySpinner.setOnItemSelectedListener(this);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

        String s = parent.getItemAtPosition(position).toString();

        if(s.equals("6A, 6B"))
        {
            startActivity(new Intent(mgmsSelect.this,mgmsSchedule1.class));
        }
        if(s.equals("6C, 6D"))
        {
            startActivity(new Intent(mgmsSelect.this,mgmsSchedule3.class));
        }
        if(s.equals("7A, 7B"))
        {
            startActivity(new Intent(mgmsSelect.this,mgmsSchedule2.class));
        }
        if(s.equals("7C, 7D"))
        {
            startActivity(new Intent(mgmsSelect.this,mgmsSchedule3.class));
        }
        if(s.equals("8A, 8B"))
        {
            startActivity(new Intent(mgmsSelect.this,mgmsSchedule1.class));
        }
        if(s.equals("8C, 8D"))
        {
            startActivity(new Intent(mgmsSelect.this,mgmsSchedule2.class));
        }


    }

    public void onNothingSelected(AdapterView<?> parent)
    {

    }

    // Go back button - Takes user to main app screen
    public void goHome(View view)
    {
        startActivity(new Intent(mgmsSelect.this,MainActivity.class));
    }

}
