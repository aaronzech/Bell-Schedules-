package com.example.zechaaron.schoolschedules.High;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
// Time
import com.example.zechaaron.schoolschedules.Analyzer;
import com.example.zechaaron.schoolschedules.MainActivity;
import com.example.zechaaron.schoolschedules.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.*;

public class osh extends AppCompatActivity {

    // School Schedule
    //--------------------------------
    String hour0End;
    String hour0Start;
    String hour1Start;
    String hour1End;
    String hour2Start;
    String hour2End;
    String hour3Start;
    String hour3End;
    String hour4Start;
    String hour4End;
    String hour5Start;
    String hour5End;
    String hour6Start;
    String hour6End;
    String hour7Start;
    String hour7End;
    String crimsonHourStart = null;
    String crimsonHourEnd = null;
    String foundationStart = null;
    String foundationsEnd = null;
    String fullSchedule = null;
    String currentTime = null;
    String hour = null;
    Date x = null;

    // Fetch analyzer class
    Analyzer analyzer = new Analyzer();

    // School name preference hour/block/period
    // School name preference hour/block/period
    public static final String PREF = "Hour ";

    // Time Start and End times
    public static final String ENDOFDAY = "14:00:00";
    public static final String STARTOFDAY = "07:30:00";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_osh);

        // Compute Current Time
        getCurrentTime();
        // Compute Day of the week.
        getDayOfWeek();

        //TextView dailySchedule = (TextView) findViewById(R.id.currentDaySchedule);
        //dailySchedule.setText(getDayOfWeek()+" Schedule");

        TextView dailyScheduleFull = (TextView) findViewById(R.id.currentDayScheduleFull);
        dailyScheduleFull.setText(fullSchedule);

        // New thread // Auto update Time
        Thread t = new Thread()
        {
            public void run()
            {
                while(!isInterrupted())
                {
                    try{
                        Thread.sleep(500); // was 1000
                        runOnUiThread(new Runnable()
                        {
                            public void run()
                            {
                                getCurrentTime();
                            }
                        });
                    }catch (InterruptedException e)
                    {
                        e.printStackTrace();
                    }
                }
            }

        };
        t.start();

    }

    // Display info to the screen
    private void display(String num) {
        TextView textView = (TextView) findViewById(R.id.current_hour);
        textView.setText(num);

        TextView textViewNew = (TextView) findViewById(R.id.display_text_view);
        textViewNew.setText(hour);
    }

    // Calulates the current day of the week, and returns it as a string
    private String getDayOfWeek()
    {
        // Get day of the week in "MONDAY" format
        SimpleDateFormat dayFormat = new SimpleDateFormat("EEEE");
        Calendar calendar = Calendar.getInstance();
        String dayOfWeek = dayFormat.format(calendar.getTime());

        TextView dayTextview = (TextView) findViewById(R.id.day);
        dayTextview.setText(dayOfWeek);


        // Select the schedule based on the day of the week
        if(dayOfWeek.equals("Tuesday"))
        {
            //Tuesday Scheudle
            hour0Start="07:30:00"; // zero hour
            hour0End="08:00:00";

            hour1Start="08:07:00"; // hour 1
            hour1End="09:24:00";

            hour2Start="09:31:00"; // hour 2
            hour2End="10:48:00";

            hour4Start="10:55:00"; // hour 4
            hour4End="12:36:00";

            hour5Start="12:43:00";
            hour5End="14:00:00";

            fullSchedule ="Hour 0 - 7:30-8:00" +
                    "\nHour 1 8:07-9:24" +
                    "\nHour 2 9:31-10:48" +
                    "\nHour 4 10:55-12:36" +
                    "\nHour 5 12:43-2:00";

        }
        else if(dayOfWeek.equals("Monday") || dayOfWeek.equals("Friday"))
        {
            //Monday-Friday Scheudle
            hour1Start="07:30:00";
            hour1End="08:21:00";

            hour2Start="08:28:00";
            hour2End="09:19:00";

            hour3Start="9:26:00";
            hour3End="10:17:00";

            hour4Start="10:24:00";
            hour4End="12:05:00";

            hour5Start="12:12:00";
            hour5End="13:03:00"; // 24 hour time here?

            hour6Start="13:10:00";
            hour6End="14:00:00";

            fullSchedule = "Hour 1 - 7:30-8:21" +
                    "\nHour 2 8:28-9:19" +
                    "\nHour 3 9:26-10:17" +
                    "\nHour 4 10:24-12:05" +
                    "\nHour 5 12:12-1:03" +
                    "\nHour 6 1:10-2:00";

        }
        else if(dayOfWeek.equals("Wednesday"))
        {
            hour1Start="07:30:00";
            hour1End="08:47:00";

            foundationStart="8:54:00";
            foundationsEnd="9:24:00";

            hour3Start="9:31:00";
            hour3End="10:48:00";

            hour4Start="10:55:00";
            hour4End="12:36:00";

            hour6Start="12:43:00";
            hour6End="14:00:00";

            fullSchedule = "Hour 1 - 7:30-8:47" +
                    "\nAdvisory - 8:54-9:24" +
                    "\nHour 3 - 9:31-10:48" +
                    "\nHour 4 - 10:55-12:36" +
                    "\nHour 6 - 12:43-2:00";
        }
        else
        {
            //Thrusday
            hour0Start="07:30:00";
            hour0End="08:00:00";

            hour2Start="08:07:00";
            hour2End="09:24:00";

            hour3Start="09:31:00";
            hour3End="10:48:00";

            hour5Start="10:55:00";
            hour5End="12:36:00"; // 24 hour time here?

            hour6Start="12:43:00";
            hour6End="14:00:00"; // 24 hour time here?

            fullSchedule = "Hour 0 - 7:30-8:00" +
                    "\nHour 2 8:07 - 9:24" +
                    "\nHour 3 9:31 - 10:48" +
                    "\nHour 5 10:55 - 12:36" +
                    "\nHour 6 12:43- 2:00";
        }
        return  dayOfWeek;
    }

    public void getCurrentTime()  {
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat mdformat = new SimpleDateFormat("HH:mm:ss"); // Math clock


        // Display Current time
        SimpleDateFormat dislaymdformat = new SimpleDateFormat("hh:mm:ss a"); // Display clock
        String strDate =  dislaymdformat.format(calendar.getTime());
        display(strDate);


        // Figure out what class is active
        currentTime =  mdformat.format(calendar.getTime());
        whatHourIsIt(currentTime);
    }

    private void whatHourIsIt(String currentTime)
    {
        try {
            // Current TIME
            Date d = new SimpleDateFormat("HH:mm:ss").parse(currentTime);
            Calendar calendarZ = Calendar.getInstance();
            calendarZ.setTime(d);
            //calendarZ.add(Calendar.DATE, 1);

            Date x = calendarZ.getTime();

            if (getDayOfWeek().equals("Monday") || getDayOfWeek().equals("Friday"))
            {
                //Hour 1 check
                if(x.after(analyzer.analizeTime(hour1Start)) && x.before(analyzer.analizeTime(hour1End)))
                {
                    hour = PREF +"1";
                }
                else if (x.after(analyzer.analizeTime(hour2Start)) && x.before(analyzer.analizeTime(hour2End)))
                {
                    hour = PREF +"2";
                }
                else if (x.after(analyzer.analizeTime(hour3Start)) && x.before(analyzer.analizeTime(hour3End)))
                {
                    hour = PREF +"3";
                }
                else if (x.after(analyzer.analizeTime(hour4Start)) && x.before(analyzer.analizeTime(hour4End)))
                {
                    hour = PREF +"4";
                }
                else if (x.after(analyzer.analizeTime(hour5Start)) && x.before(analyzer.analizeTime(hour5End)))
                {
                    hour = PREF +"5";
                }
                else if (x.after(analyzer.analizeTime(hour6Start)) && x.before(analyzer.analizeTime(hour6End)))
                {
                    hour = PREF +"6";
                }
                else if(x.after(analyzer.analizeTime(STARTOFDAY)) && x.before(analyzer.analizeTime(ENDOFDAY)))
                {
                    hour = "Passing Time";
                }
                else
                {
                    hour = "No Active Classes";
                }
            }

            // Tuesday, Wednesday, Thrusday Scheudle
            if((getDayOfWeek().equals("Tuesday")))
            {
                // 1 Hour
                if(x.after(analyzer.analizeTime(hour0Start)) && x.before(analyzer.analizeTime(hour0End)))
                {
                    hour = PREF +"0";
                }
                //2nd Hour
                else if(x.after(analyzer.analizeTime(hour1Start)) && x.before(analyzer.analizeTime(hour1End)))
                {
                    hour = PREF +"1";
                }
                // 4th hour
                else if(x.after(analyzer.analizeTime(hour2Start)) && x.before(analyzer.analizeTime(hour2End)))
                {
                    hour = PREF +"2";
                }
                // 5th hour
                else if(x.after(analyzer.analizeTime(hour4Start)) && x.before(analyzer.analizeTime(hour4End)))
                {
                    hour = PREF +"4";
                }
                // 6th hour
                else if(x.after(analyzer.analizeTime(hour5Start)) && x.before(analyzer.analizeTime(hour5End)))
                {
                    hour = PREF +"5";
                }
                else if(x.after(analyzer.analizeTime(STARTOFDAY)) && x.before(analyzer.analizeTime(ENDOFDAY)))
                {
                    hour = "Passing Time";
                }
                else
                {
                    hour = "No Active Classes";
                }
            }

            if((getDayOfWeek().equals("Wednesday")))
            {
                //1st Hour
                if(x.after(analyzer.analizeTime(hour1Start)) && x.before(analyzer.analizeTime(hour1End)))
                {
                    hour = PREF +"1";
                }
                // Foundaitons
                else if(x.after(analyzer.analizeTime(foundationStart)) && x.before(analyzer.analizeTime(foundationsEnd)))
                {
                    hour = "Advisory";
                }
                //3nd Hour
                else if(x.after(analyzer.analizeTime(hour3Start)) && x.before(analyzer.analizeTime(hour3End)))
                {
                    hour = PREF +"3 ";
                }

                // 4th hour
                else if(x.after(analyzer.analizeTime(hour4Start)) && x.before(analyzer.analizeTime(hour4End)))
                {
                    hour = PREF +"4";
                }

                // 6th hour
                else if(x.after(analyzer.analizeTime(hour6Start)) && x.before(analyzer.analizeTime(hour6End)))
                {
                    hour = PREF +"6";
                }
                else if(x.after(analyzer.analizeTime(STARTOFDAY)) && x.before(analyzer.analizeTime(ENDOFDAY)))
                {
                    hour = "Passing Time";
                }
                else
                {
                    hour = "No Active Classes";
                }
            }

            if((getDayOfWeek().equals("Thursday")))
            {
                // Crimson Hour
                if(x.after(analyzer.analizeTime(hour0Start)) && x.before(analyzer.analizeTime(hour0End)))
                {
                    hour = PREF +"0";
                }
                // 2nd hour
                else if(x.after(analyzer.analizeTime(hour2Start)) && x.before(analyzer.analizeTime(hour2End)))
                {
                    hour = PREF +"2";
                }
                //3nd Hour
                else if(x.after(analyzer.analizeTime(hour3Start)) && x.before(analyzer.analizeTime(hour3End)))
                {
                    hour = PREF +"3";
                }
                // 5th hour
                else if(x.after(analyzer.analizeTime(hour5Start)) && x.before(analyzer.analizeTime(hour5End)) )
                {
                    hour = PREF +"5";
                }
                // 6th hour
                else if(x.after(analyzer.analizeTime(hour6Start)) && x.before(analyzer.analizeTime(hour6End)))
                {
                    hour = PREF +"6";
                }
                else if(x.after(analyzer.analizeTime(STARTOFDAY)) && x.before(analyzer.analizeTime(ENDOFDAY)))
                {
                    hour = "Passing Time";
                }
                else
                {
                    hour = "No Active Classes";
                }

            }

        } catch (ParseException e) {
            e.printStackTrace();
            Toast.makeText(this,"ERROR",Toast.LENGTH_LONG).show();
        }

    }


    // Go back button - Takes user to main app screen
    public void goHome(View view)
    {
        startActivity(new Intent(osh.this,MainActivity.class));
    }

}
