package com.example.zechaaron.schoolschedules;

import android.Manifest;
import android.app.Notification;
import android.content.Intent;
import android.location.Location;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.zechaaron.schoolschedules.High.MGSH;
import com.example.zechaaron.schoolschedules.High.osh;
import com.example.zechaaron.schoolschedules.High.pcsh;
import com.example.zechaaron.schoolschedules.Middle.NVMS;
import com.example.zechaaron.schoolschedules.Middle.bms;
import com.example.zechaaron.schoolschedules.Middle.mgms.mgmsSelect;
import com.example.zechaaron.schoolschedules.Middle.oms.omsSelect;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    Button btnGetLoc;
    Button notifBTN;
   private NotificationManagerCompat notificationManager;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Doesn't work
        notificationManager = NotificationManagerCompat.from(this);

        // Displays Version Number of the App
        versionNumber("0.2.0");

      // Notification Logic

      notifBTN = (Button) findViewById(R.id.button1);
      notifBTN.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View v) {
              Notification notification = new NotificationCompat.Builder(MainActivity.this,App.Channel_1_ID)
                      .setSmallIcon(R.mipmap.ic_launcher)
                      .setContentTitle("HIII")
                      .setContentText("HHIIIII")
                      .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                      .setCategory(NotificationCompat.CATEGORY_REMINDER)
                      .build();

              notificationManager.notify(1,notification);

          }
      });

      // Spinner Logic
      Spinner mySpinner = (Spinner) findViewById(R.id.spinnerSchool);

      ArrayAdapter<String> myAdapter = new ArrayAdapter<>(MainActivity.this,
              android.R.layout.simple_list_item_1,getResources().getStringArray(R.array.Schools));

      myAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

      mySpinner.setAdapter(myAdapter);

      mySpinner.setOnItemSelectedListener(this);

      // Location
       btnGetLoc = (Button) findViewById(R.id.getLoc);
        ActivityCompat.requestPermissions(MainActivity.this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION},123);
       btnGetLoc.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               GPStracker g = new GPStracker(getApplicationContext());
               Location l = g.getLocation();
               if(l!=null)
               {
                   double lat = l.getLatitude();
                   double lon = l.getLongitude();

                   // MGSH
                   //45.137   -93.465
                   //45.130   -93.457
                   if(lat>=45.130  && lat<=45.137 && lon<=-93.457 && lon>=-93.465)
                   {
                       startActivity(new Intent(MainActivity.this,MGSH.class));
                   }
                   // OSH
                   //45.118   -93.405
                   //45.122   -93.409
                   else if(lat>=45.118  && lat<=45.122 && lon<=-93.405 && lon>=-93.409)
                   {
                       Toast.makeText(getApplicationContext(),"OSH", Toast.LENGTH_LONG).show();
                   }
                   // PCSH
                   //45.090367  -93.343099
                   //45.087887   -93.345160
                   else if(lat>=45.087887  && lat<=45.090367 && lon<=-93.343099 && lon>=-93.345160)
                   {
                       Toast.makeText(getApplicationContext(),"PCSH", Toast.LENGTH_LONG).show();
                   }
                   // Brooklyn Middle
                   //45.090367  -93.342874
                   //45.087887   -93.341321
                   else if(lat>=45.087887  && lat<=45.090367 && lon<=-93.341321 && lon>=-93.342874)
                   {
                       Toast.makeText(getApplicationContext(),"BMS", Toast.LENGTH_LONG).show();
                   }
                   // Osseo Middle
                   //45.123349  -93.409583
                   //45.121804  -93.413510
                   else if(lat>=45.121804 && lat<=45.123349 && lon<=-93.409583 && lon>=-93.413510)
                   {
                       Toast.makeText(getApplicationContext(),"OMS", Toast.LENGTH_LONG).show();
                   }
                   // NVMS
                   //45.079979 -93.355690
                   //45.077950  -93.35249
                   else if(lat>=45.077950 && lat<=45.079979 && lon<=-93.35249 && lon>=-93.355690)
                   {
                       Toast.makeText(getApplicationContext(),"NVMS", Toast.LENGTH_LONG).show();
                   }
                   // MGMS
                   //45.081709 -93.430931
                   //45.081717 -93.425070
                   else if(lat>=45.080225 && lat<=45.08366 && lon<=-93.425070 && lon>=-93.430931)
                   {
                       Toast.makeText(getApplicationContext(),"MGMS", Toast.LENGTH_LONG).show();
                   }
                   else
                   {
                       Toast.makeText(getApplicationContext(),"Not Near a School", Toast.LENGTH_LONG).show();
                   }
               }

               else  Toast.makeText(getApplicationContext(),"NO LOC", Toast.LENGTH_LONG).show();
           }
       });




    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
    {
        String s = parent.getItemAtPosition(position).toString();
        //Toast.makeText(this,s,Toast.LENGTH_LONG).show();
        if(s.equals("Maple Grove Senior"))
        {
           startActivity(new Intent(MainActivity.this,MGSH.class));
        }
        if(s.equals("Osseo Senior"))
        {
            startActivity(new Intent(MainActivity.this,osh.class));
        }
        if(s.equals("Brooklyn Middle"))
        {
            startActivity(new Intent (MainActivity.this,bms.class));
        }
        if(s.equals("Osseo Middle"))
        {
            startActivity(new Intent (MainActivity.this,omsSelect.class));
        }

        if(s.equals("Park Center Senior"))
        {
           // Toast.makeText(this,s,Toast.LENGTH_LONG).show();
            startActivity(new Intent (MainActivity.this,pcsh.class));
        }
        if(s.equals("North View Middle"))
        {
            startActivity(new Intent (MainActivity.this,NVMS.class));
        }
        if(s.equals("Maple Grove Middle"))
        {
            startActivity(new Intent (MainActivity.this,mgmsSelect.class));
        }

    }

    public void onNothingSelected(AdapterView<?> parent)
    {

    }

    private void versionNumber(String number)
    {
        TextView versionNumber = (TextView) findViewById(R.id.version_text_view);
        versionNumber.setText("Version: "+number);

    }





    public void OnClick1()
    {

    }







}
