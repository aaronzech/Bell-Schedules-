package com.example.zechaaron.schoolschedules.Middle;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
// Time
import com.example.zechaaron.schoolschedules.Analyzer;
import com.example.zechaaron.schoolschedules.MainActivity;
import com.example.zechaaron.schoolschedules.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Period;
import java.util.Calendar;
import java.util.*;

public class NVMS extends AppCompatActivity{

    String day = "A";

    // Constants
    static String BREAKFAST_START = "07:50:00";
    static String BREAKFAST_END = "08:10:00";
    static String ADVISORY_START = "08:10:00";
    static String ADVISORY_END = "08:42:00";

    static String BLOCK_1_START = "08:46:00";
    static String BLOCK_1_END = "10:03:00";

    static String BLOCK_2_START = "10:07:00";
    static String BLOCK_2_END = "11:24:00";

    static String BLOCK_3_START = "11:28:00";
    static String BLOCK_3_END = "13:19:00";

    static String BLOCK_4_START = "13:23:00";
    static String BLOCK_4_END = "14:40:00";

    static String PREF = "Period: ";

    String fullSchedule = null;

    // Fetch analyzer class
    Analyzer analyzer = new Analyzer();

    // Time Start and End times
    public static final String ENDOFDAY = "07:50:00";
    public static final String STARTOFDAY = "14:40:00";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nvms);
        getCurrentTime();

        getDayOfWeek();
        // notification();

        TextView dailySchedule = (TextView) findViewById(R.id.currentDaySchedule);
        dailySchedule.setText(getDayOfWeek()+" Schedule");

        TextView dailyScheduleFull = (TextView) findViewById(R.id.currentDayScheduleFull);
        dailyScheduleFull.setText(fullSchedule);

        // New thread // Auto update Time
        Thread t = new Thread()
        {
            public void run()
            {
                while(!isInterrupted())
                {
                    try{
                        Thread.sleep(500);
                        runOnUiThread(new Runnable()
                        {
                            public void run()
                            {
                                getCurrentTime();
                            }
                        });
                    }catch (InterruptedException e)
                    {
                        e.printStackTrace();
                    }
                }
            }

        };

        t.start();

    }

    // Calulates the current day of the week, and returns it as a string
    private String getDayOfWeek()
    {
        // Get day of the week
        SimpleDateFormat dayFormat = new SimpleDateFormat("EEEE");
        Calendar calendar = Calendar.getInstance();
        String dayOfWeek = dayFormat.format(calendar.getTime());
        TextView dayTextview = (TextView) findViewById(R.id.day);
        dayTextview.setText(dayOfWeek);
        Log.d("mytag",dayOfWeek);

        if(day.equals("A"))
        {
            fullSchedule = "A DAY" +
                    "\nAdvisory 8:10-8:42" +
                    "\nPeriod 1 8:46-10:03" +
                    "\nPeriod 2 10:07-11:24" +
                    "\nPeriod 3 11:28-1:19" +
                    "\nPeriod 4 1:23-2:40";
        }
        else
        {
            fullSchedule = "B DAY" +
                    "\nAdvisory 8:10-8:42" +
                    "\nPeriod 5 8:46-10:03" +
                    "\nPeriod 6 10:07-11:24" +
                    "\nPeriod 7 11:28-1:19" +
                    "\nPeriod 8 1:23-2:40";
        }


        return  dayOfWeek;

    }

    String currentTime = null;
    String hour = null;
    public void getCurrentTime()  {
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat mdformat = new SimpleDateFormat("hh:mm:ss a"); //a for am

        String strDate =  mdformat.format(calendar.getTime());
        display(strDate);
        currentTime =  mdformat.format(calendar.getTime());
        whatHourIsIt(currentTime);

    }
    // Go back button - Takes user to main app screen
    public void goHome(View view)
    {
        startActivity(new Intent(NVMS.this,MainActivity.class));
    }

    private void display(String num) {
        TextView textView = (TextView) findViewById(R.id.current_hour);
        textView.setText(num);

        TextView textViewNew = (TextView) findViewById(R.id.display_text_view);
        textViewNew.setText(hour);
    }

    // MGSH Schedule
    // HOUR 1 7:30-8:25
    private void whatHourIsIt(String currentTime)
    {

        try {
            // Current TIME
            Date d = new SimpleDateFormat("HH:mm:ss").parse(currentTime);
            Calendar calendarZ = Calendar.getInstance();
            calendarZ.setTime(d);
            //calendarZ.add(Calendar.DATE, 1);

            Date x = calendarZ.getTime();


            //Hour 1 check
            if(x.after(analyzer.analizeTime(BREAKFAST_START)) && x.before(analyzer.analizeTime(BREAKFAST_END)))
            {
                hour = "Breakfast";
            }
            else if (x.after(analyzer.analizeTime(BLOCK_1_START)) && x.before(analyzer.analizeTime(BLOCK_1_END)))
            {
                if(day.equals("A"))
                {
                    hour = PREF+"1";
                }
                else
                {
                    hour = PREF+"5";
                }
            }
            else if (x.after(analyzer.analizeTime(BLOCK_2_START)) && x.before(analyzer.analizeTime(BLOCK_2_END)))
            {
                if(day.equals("A"))
                {
                    hour = PREF+"2";
                }
                else
                {
                    hour = PREF+"6";
                }
            }
            else if (x.after(analyzer.analizeTime(BLOCK_3_START)) && x.before(analyzer.analizeTime(BLOCK_3_END)))
            {
                if(day.equals("A"))
                {
                    hour = PREF+"3";
                }
                else
                {
                    hour = PREF+"7";
                }
            }
            else if (x.after(analyzer.analizeTime(BLOCK_4_START)) && x.before(analyzer.analizeTime(BLOCK_4_END)))
            {
                if(day.equals("A"))
                {
                    hour = PREF+"4";
                }
                else
                {
                    hour = PREF+"8";
                }
            }
            else if(x.after(analyzer.analizeTime(STARTOFDAY)) && x.before(analyzer.analizeTime(ENDOFDAY)))
            {
                hour = "Passing Time";
            }
            else
            {
                hour = "No Active Classes";
            }

            // Adjusted Schedule
        } catch (ParseException e) {
            e.printStackTrace();
            Toast.makeText(this,"ERROR",Toast.LENGTH_LONG).show();
        }

    }

}
