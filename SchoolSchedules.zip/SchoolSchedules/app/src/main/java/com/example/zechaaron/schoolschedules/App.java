package com.example.zechaaron.schoolschedules;

import android.app.Application;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;
import android.os.Bundle;

public class App extends Application {
    public  static  final String Channel_1_ID= "channel1";


    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate();
        createNotificationChannel();

    }
    private void createNotificationChannel()
    {
        if(Build.VERSION.SDK_INT>Build.VERSION_CODES.O)
        {
            NotificationChannel channel1 = new NotificationChannel(Channel_1_ID,"Channel 1", NotificationManager.IMPORTANCE_DEFAULT);
            channel1.setDescription("This is channel 1");

            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel1);

        }



    }


}
