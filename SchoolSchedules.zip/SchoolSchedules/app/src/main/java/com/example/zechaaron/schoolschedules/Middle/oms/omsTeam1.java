package com.example.zechaaron.schoolschedules.Middle.oms;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.example.zechaaron.schoolschedules.Analyzer;
import com.example.zechaaron.schoolschedules.MainActivity;
import com.example.zechaaron.schoolschedules.Middle.NVMS;
import com.example.zechaaron.schoolschedules.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class omsTeam1 extends AppCompatActivity {


    static String ADVISORY_START = "08:10:00";
    static String ADVISORY_END = "08:30:00";

    static String CORE_1_START = "08:30:00";
    static String CORE_1_END = "09:40:00";

    static String CORE_2_START = "09:40:00";
    static String CORE_2_END = "10:50:00";

    static String CORE_3_START = "10:50:00";
    static String CORE_3_END = "12:00:00";

    static String ENRICHMENT_START = "13:10:00";
    static String ENRICHMENT_END = "13:55:00";

    static String ENRICHMENT1_START = "13:55:00";
    static String ENRICHMENT1_END = "14:40:00";

    static String PREF = "Core: ";

    String fullSchedule = "Advisory 8:10-8:30" +
            "\nCore 1 8:30-9:40" +
            "\nCore 2 9:40-10:50" +
            "\nCore 3 10:50-12:00" +
            "\nEnrichment 12:00-1:10" +
            "\nExplore 1 1:10-1:55" +
            "\nExplore 2 1;55-2:40";

    // Fetch analyzer class
    Analyzer analyzer = new Analyzer();

    // Time Start and End times
    public static final String ENDOFDAY = "08:10:00";
    public static final String STARTOFDAY = "14:40:00";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_oms_team1);

        getCurrentTime();

        getDayOfWeek();
        // notification();

        TextView dailySchedule = (TextView) findViewById(R.id.currentDaySchedule);
        dailySchedule.setText(getDayOfWeek()+" Schedule");

        TextView dailyScheduleFull = (TextView) findViewById(R.id.currentDayScheduleFull);
        dailyScheduleFull.setText(fullSchedule);

        // New thread // Auto update Time
        Thread t = new Thread()
        {
            public void run()
            {
                while(!isInterrupted())
                {
                    try{
                        Thread.sleep(500);
                        runOnUiThread(new Runnable()
                        {
                            public void run()
                            {
                                getCurrentTime();
                            }
                        });
                    }catch (InterruptedException e)
                    {
                        e.printStackTrace();
                    }
                }
            }

        };

        t.start();

    }
    // Calulates the current day of the week, and returns it as a string
    private String getDayOfWeek()
    {
        // Get day of the week
        SimpleDateFormat dayFormat = new SimpleDateFormat("EEEE");
        Calendar calendar = Calendar.getInstance();
        String dayOfWeek = dayFormat.format(calendar.getTime());
        TextView dayTextview = (TextView) findViewById(R.id.day);
        dayTextview.setText(dayOfWeek);
        Log.d("mytag",dayOfWeek);

        return  dayOfWeek;

    }

    String currentTime = null;
    String hour = null;
    public void getCurrentTime()  {
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat mdformat = new SimpleDateFormat("hh:mm:ss a"); //a for am

        String strDate =  mdformat.format(calendar.getTime());
        display(strDate);
        currentTime =  mdformat.format(calendar.getTime());
        whatHourIsIt(currentTime);

    }
    // Go back button - Takes user to main app screen
    public void goHome(View view)
    {
        startActivity(new Intent(omsTeam1.this,omsSelect.class));
    }

    private void display(String num) {
        TextView textView = (TextView) findViewById(R.id.current_hour);
        textView.setText(num);

        TextView textViewNew = (TextView) findViewById(R.id.display_text_view);
        textViewNew.setText(hour);
    }

    // MGSH Schedule
    // HOUR 1 7:30-8:25
    private void whatHourIsIt(String currentTime)
    {

        try {
            // Current TIME
            Date d = new SimpleDateFormat("HH:mm:ss").parse(currentTime);
            Calendar calendarZ = Calendar.getInstance();
            calendarZ.setTime(d);
            //calendarZ.add(Calendar.DATE, 1);

            Date x = calendarZ.getTime();


            //Hour 1 check
            if(x.after(analyzer.analizeTime(ADVISORY_START)) && x.before(analyzer.analizeTime(ADVISORY_END)))
            {
                hour = "Advisory";
            }
            else if (x.after(analyzer.analizeTime(CORE_1_START)) && x.before(analyzer.analizeTime(CORE_1_END)))
            {
                    hour = PREF+"1";
            }
            else if (x.after(analyzer.analizeTime(CORE_2_START)) && x.before(analyzer.analizeTime(CORE_2_END)))
            {
                    hour = PREF+"2";
            }
            else if (x.after(analyzer.analizeTime(CORE_3_START)) && x.before(analyzer.analizeTime(CORE_3_END)))
            {
                    hour = PREF+"3";
            }
            else if (x.after(analyzer.analizeTime(ENRICHMENT_START)) && x.before(analyzer.analizeTime(ENRICHMENT_END)))
            {

                hour="ENRICHMENT";
            }
            else if (x.after(analyzer.analizeTime(ENRICHMENT1_START)) && x.before(analyzer.analizeTime(ENRICHMENT1_END)))
            {

                hour="ENRICHMENT 2";
            }
            else if(x.after(analyzer.analizeTime(STARTOFDAY)) && x.before(analyzer.analizeTime(ENDOFDAY)))
            {
                hour = "Passing Time";
            }
            else
            {
                hour = "No Active Classes";
            }

            // Adjusted Schedule
        } catch (ParseException e) {
            e.printStackTrace();
            Toast.makeText(this,"ERROR",Toast.LENGTH_LONG).show();
        }

    }
}
